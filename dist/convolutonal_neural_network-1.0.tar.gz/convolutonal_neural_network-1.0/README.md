# 畳みこみニューラルネットワークを使おう

## 解説資料

- [page](https://saitoryuya945.github.io/convolutonal_neural_network/)
