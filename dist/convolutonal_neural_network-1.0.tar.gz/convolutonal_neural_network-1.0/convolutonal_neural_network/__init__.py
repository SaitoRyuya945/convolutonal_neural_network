from .convolution import Convolution
from .qt_app import MatplotlibWindow
