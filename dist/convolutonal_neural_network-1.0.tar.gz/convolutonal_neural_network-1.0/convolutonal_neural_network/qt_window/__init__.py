from .convo_window import Ui_MainWindow
